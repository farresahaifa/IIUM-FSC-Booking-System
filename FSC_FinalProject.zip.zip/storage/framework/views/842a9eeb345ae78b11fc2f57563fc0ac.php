<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Panel - IIUM Female Sports Complex</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://cdn.tailwindcss.com"></script> 
</head>
<body style="background-color: #ffffff; overflow-y: auto;">

    <header class="top-header">
        <div class="header-branding">
            <div class="menu-toggle" onclick="toggleSidebar()">&#9776;</div>
            <img src="<?php echo e(asset('images/fsc-logo.png')); ?>" class="mini-logo">
            <div class="header-text">
                <span class="header-main">IIUM FEMALE</span>
                <span class="header-sub">SPORT COMPLEX</span>
            </div>
        </div>

        <div class="user-profile">
            <a href="<?php echo e(route('staff.profile')); ?>" style="text-decoration: none; color: inherit; display: flex; align-items: center;">
                <?php if(auth()->guard()->check()): ?>
                    <span class="user-name"><?php echo e(strtoupper(Auth::user()->name)); ?></span>
                    <?php if(Auth::user()->profile_photo): ?>
                        <img src="<?php echo e(asset('storage/' . Auth::user()->profile_photo)); ?>" class="user-avatar">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/profile-pic.png')); ?>" class="user-avatar">
                    <?php endif; ?>
                <?php endif; ?>
            </a>

            <?php if(auth()->guard()->check()): ?>
            <a href="#" class="header-logout" 
               onclick="if(confirm('Logout?')) { event.preventDefault(); document.getElementById('logout-form').submit(); }">
                LOGOUT
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <?php endif; ?>
        </div>
    </header>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <nav class="nav-links">
                <div class="menu-label" style="padding-top:20px;">Staff Menu</div>
                <a href="<?php echo e(route('staff.dashboard')); ?>" class="<?php echo e(request()->routeIs('staff.dashboard') ? 'active' : ''); ?>">Dashboard</a>
                <div class="divider"></div>
                <a href="<?php echo e(route('staff.profile')); ?>" class="<?php echo e(request()->routeIs('staff.profile') ? 'active' : ''); ?>">My Profile</a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="content-body">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('collapsed');
        }
    </script>
</body>
</html><?php /**PATH C:\Users\farre\FSC_Project(1)\resources\views/layouts/staff_layout.blade.php ENDPATH**/ ?>