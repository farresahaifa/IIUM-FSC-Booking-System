

<?php $__env->startSection('content'); ?>
<div class="content-body staff-dashboard"> 
    <h2 class="dashboard-title">Booking Details</h2>

    <div class="booking-container">
        <div class="table-responsive">
            <table class="staff-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Matric No</th>
                        <th>Sports</th>
                        <th>Court</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($booking->user_name); ?></td>
                        <td class="matric-text"><?php echo e($booking->matric_number ?? 'N/A'); ?></td>
                        <td><span class="pill-gray"><?php echo e(ucfirst($booking->sport_type)); ?> </span></td>
                        <td><span class="pill-gray">Court <?php echo e($booking->court_number); ?> </span></td>
                        <td><span class="pill-gray"><?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('M d, Y')); ?></span></td>
                        <td><?php echo e($booking->time_slot); ?></td>
                        <td>
                            <div class="custom-dropdown">
                                <div class="dropdown-trigger" onclick="toggleMenu(<?php echo e($booking->id); ?>)">
                                    <span>
                                        <span class="status-icon bg-<?php echo e(str_replace([' ', '-'], '', strtolower($booking->status))); ?>"></span>
                                        <?php echo e($booking->status); ?>

                                    </span>
                                    <small>▼</small>
                                </div>

                                <ul class="dropdown-menu" id="menu-<?php echo e($booking->id); ?>">
                                    <li class="status-confirmed" onclick="submitStatus(<?php echo e($booking->id); ?>, 'Confirmed')">
                                        <span class="status-icon bg-confirmed"></span> Confirmed
                                    </li>

                                    <li class="status-checkin" onclick="submitStatus( 
                                        <?php echo e($booking->id); ?>, 
                                        'Check-In', 
                                        '<?php echo e($booking->user_name); ?>', 
                                        '<?php echo e($booking->matric_number); ?>', 
                                        '<?php echo e(ucfirst($booking->sport_type)); ?>', 
                                        'Court <?php echo e($booking->court_number); ?>', 
                                        '<?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d M Y')); ?>', 
                                        '<?php echo e($booking->time_slot); ?>'
                                    )">
                                        <span class="status-icon bg-checkin"></span> Check-In
                                    </li>

                                    <li class="status-cancelled" onclick="submitStatus(<?php echo e($booking->id); ?>, 'Cancelled')">
                                        <span class="status-icon bg-cancelled"></span> Cancelled 
                                    </li>
                                </ul>

                                <form id="form-<?php echo e($booking->id); ?>" action="<?php echo e(route('status.update', $booking->id)); ?>" method="POST" style="display:none;">
                                    <?php echo csrf_field(); ?> 
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" id="input-<?php echo e($booking->id); ?>">
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="confirmModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-check-icon">✔</div>
        </div>
        <div class="modal-body">
            <p><strong>Name:</strong> <span id="display-name"></span></p>
            <p><strong>Matric No:</strong> <span id="display-matric"></span></p>
            <p><strong>Sport:</strong> <span id="display-sport"></span></p>
            <p><strong>Court:</strong> <span id="display-court"></span></p>
            <p><strong>Date:</strong> <span id="display-date"></span></p>
            <p><strong>Time:</strong> <span id="display-time"></span></p>
        </div>
        <div class="modal-footer">
            <button class="btn-cancel" onclick="closeModal()">Cancel</button>
            <button class="btn-confirm" id="finalConfirmBtn">Confirm</button>
        </div>
    </div>
</div>

<script>
let currentBookingId = null;
let currentStatus = null;

function toggleMenu(id) {
    document.querySelectorAll('.dropdown-menu').forEach(menu => {
        if(menu.id !== 'menu-'+id) menu.style.display = 'none';
    });
    const menu = document.getElementById('menu-' + id);
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

function submitStatus(id, status, name = '', matric = '', sport = '', court = '', date = '', time = '') {
    // If not Check-In, update immediately
    if (status !== 'Check-In') {
        document.getElementById('input-' + id).value = status;
        document.getElementById('form-' + id).submit();
        return;
    }

    // If Check-In, show the modal
    currentBookingId = id;
    currentStatus = status;

    document.getElementById('display-name').innerText = name;
    document.getElementById('display-matric').innerText = matric;
    document.getElementById('display-sport').innerText = sport;
    document.getElementById('display-court').innerText = court;
    document.getElementById('display-date').innerText = date;
    document.getElementById('display-time').innerText = time;

    document.getElementById('confirmModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('confirmModal').style.display = 'none';
}

// Final Confirm logic
document.getElementById('finalConfirmBtn').onclick = function() {
    if (currentBookingId && currentStatus) {
        document.getElementById('input-' + currentBookingId).value = currentStatus;
        document.getElementById('form-' + currentBookingId).submit();
    }
};

// Close dropdown when clicking outside
window.onclick = function(event) {
    if (!event.target.closest('.custom-dropdown')) {
        document.querySelectorAll('.dropdown-menu').forEach(menu => menu.style.display = 'none');
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farre\FSC_Project(1)\resources\views/staff/staff_dashboard.blade.php ENDPATH**/ ?>