


<?php $__env->startSection('content'); ?>




<div class="dashboard-wrapper">
    <aside class="sidebar">
        <div class="nav-links">
            <a href="<?php echo e(route('dashboard')); ?>">Homepage</a>
            <div class="booking-menu">
                <span class="menu-label">BOOK A COURT</span>
                <ul class="sport-list">
                    <li><a href="<?php echo e(route('booking.select', 'badminton')); ?>">Badminton</a></li>
                    <li><a href="<?php echo e(route('booking.select', 'netball')); ?>">Netball</a></li>
                    <li><a href="<?php echo e(route('booking.select', 'pingpong')); ?>">Ping Pong</a></li>
                </ul>
            </div>
            <div class="divider"></div>
            <a href="<?php echo e(route('student.profile')); ?>">My Profile</a>
            <a href="<?php echo e(route('student.history')); ?>" class="active">Booking History</a>
        </div>
    </aside>


    <main class="main-content bg-white">
    <div class="history-container" style="padding: 50px 70px;">
       
        <nav class="breadcrumb-nav">
            <a href="<?php echo e(route('dashboard')); ?>">Home</a>
            <span class="text-gray-400">></span>
            <span class="breadcrumb-current">Booking History</span>
        </nav>


        <h1 class="history-title-dark">
            My Booking History
        </h1>


        <div class="table-wrapper">
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Sports</th>
                        <th>Court</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <span class="data-badge">
                                <?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d M Y')); ?>

                            </span>
                        </td>
                        <td class="font-semibold text-gray-700">
                            <?php echo e($booking->time_slot); ?>

                        </td>
                        <td>
                            <span class="data-badge">
                                <?php echo e(ucfirst($booking->sport_type)); ?>

                            </span>
                        </td>
                        <td>
                            <span class="data-badge">
                                Court <?php echo e($booking->court_number); ?>

                            </span>
                        </td>
                        <td>
                            <?php if($booking->status == 'cancelled'): ?>
                                <span class="status-cancelled">Cancelled</span>
                            <?php else: ?>
                                <span class="status-confirmed">Confirmed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-10 text-gray-500">
                            No booking history found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
</div>


<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    // We check if it exists first to avoid errors
    if(sidebar) {
        sidebar.classList.toggle('collapsed');
    }
}
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farre\FSC_Project\resources\views/booking/history.blade.php ENDPATH**/ ?>