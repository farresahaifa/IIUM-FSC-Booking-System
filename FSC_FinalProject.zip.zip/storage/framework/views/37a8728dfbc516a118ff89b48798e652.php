
<?php $__env->startSection('content'); ?>


<div class="dashboard-wrapper">
    <aside class="sidebar">
    <div class="nav-links">
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">Homepage</a>
       
        <div class="booking-menu">
            <span class="menu-label">BOOK A COURT</span>
            <ul class="sport-list">
                <li>
                    <a href="<?php echo e(route('booking.select', 'badminton')); ?>"
                       class="<?php echo e(request()->is('*badminton*') ? 'active-sport' : ''); ?>">Badminton</a>
                </li>
                <li>
                    <a href="<?php echo e(route('booking.select', 'netball')); ?>"
                       class="<?php echo e(request()->is('*netball*') ? 'active-sport' : ''); ?>">Netball</a>
                </li>
                <li>
                    <a href="<?php echo e(route('booking.select', 'pingpong')); ?>"
                       class="<?php echo e(request()->is('*pingpong*') ? 'active-sport' : ''); ?>">Ping Pong</a>
                </li>
            </ul>
        </div>


        <div class="divider"></div>
        <a href="<?php echo e(route('student.profile')); ?>" class="<?php echo e(request()->routeIs('student.profile') ? 'active' : ''); ?>">My Profile</a>
        <a href="<?php echo e(route('student.history')); ?>" class="<?php echo e(request()->routeIs('booking.history') ? 'active' : ''); ?>">Booking History</a>
    </div>
</aside>
    <main class="main-content">
        <section class="content-body">
            <h2 class="section-title">PICK YOUR SPORT</h2>
           <div class="sport-grid">
    <div class="sport-card">
        <img src="<?php echo e(asset('images/badminton.png')); ?>" alt="Badminton">
        <div class="sport-label">BADMINTON</div>
        <a href="<?php echo e(route('booking.select', 'badminton')); ?>" class="btn-book">BOOK NOW</a>
    </div>


    <div class="sport-card">
        <img src="<?php echo e(asset('images/netball.png')); ?>" alt="Netball">
        <div class="sport-label">NETBALL</div>
        <a href="<?php echo e(route('booking.select', 'netball')); ?>" class="btn-book">BOOK NOW</a>
    </div>


    <div class="sport-card">
        <img src="<?php echo e(asset('images/pingpong.png')); ?>" alt="Ping Pong">
        <div class="sport-label">PING PONG</div>
        <a href="<?php echo e(route('booking.select', 'pingpong')); ?>" class="btn-book">BOOK NOW</a>
    </div>
</div>
        </section>
    </main>
</div>


<script>
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('collapsed');
}
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farre\FSC_FinalProject\resources\views/student_home.blade.php ENDPATH**/ ?>