

<?php $__env->startSection('content'); ?>
<div class="booking-container">
    <div class="booking-header-bar">
        Booking Details
    </div>
    
    <div class="table-responsive">
        <table class="staff-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Sports</th>
                    <th>Court</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($booking->user_name); ?></td>
                    <td><span class="pill-gray"><?php echo e(ucfirst($booking->sport_type)); ?> ▾</span></td>
                    <td><span class="pill-gray">Court <?php echo e($booking->court_number); ?> ▾</span></td>
                    <td><span class="pill-gray"><?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('M d, Y')); ?></span></td>
                    <td><?php echo e($booking->time_slot); ?></td>
                    <td>
                        <form action="<?php echo e(route('status.update', $booking->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <select name="status" onchange="this.form.submit()" class="status-dropdown <?php echo e(strtolower($booking->status)); ?>">
                                <option value="Pending" <?php echo e($booking->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="Confirmed" <?php echo e($booking->status == 'Confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                                <option value="Check-In" <?php echo e($booking->status == 'Check-In' ? 'selected' : ''); ?>>Check-In</option>
                                <option value="Cancelled" <?php echo e($booking->status == 'Cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                            </select>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<style>
    /* Table Container Styling */
    .booking-container {
        background: white;
        border: 2px solid #3d7a5d;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .booking-header-bar {
        background-color: #3d7a5d;
        color: white;
        padding: 15px 20px;
        font-weight: bold;
        font-size: 1.1rem;
    }

    /* Table Structure */
    .staff-table {
        width: 100%;
        border-collapse: collapse;
    }

    .staff-table th {
        background-color: #4a9471;
        color: white;
        text-align: left;
        padding: 12px 15px;
        font-weight: 600;
        border: 1px solid #3d7a5d;
    }

    .staff-table td {
        padding: 12px 15px;
        border: 1px solid #e0e0e0;
        vertical-align: middle;
        font-size: 0.95rem;
    }

    /* Gray Selection Pills (Sport, Court, Date) */
    .pill-gray {
        background-color: #f3f4f6;
        border: 1px solid #d1d5db;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        color: #374151;
        display: inline-block;
    }

    /* Status Dropdown Pills */
    .status-dropdown {
        border-radius: 20px;
        padding: 5px 15px;
        font-weight: bold;
        font-size: 0.85rem;
        border: 1px solid transparent;
        cursor: pointer;
        appearance: none; /* Removes default arrow to look like a pill */
        text-align: center;
    }

    .status-dropdown.pending {
        background-color: #fef3c7;
        color: #d97706;
        border-color: #f59e0b;
    }

    .status-dropdown.confirmed {
        background-color: #ecfdf5;
        color: #059669;
        border-color: #10b981;
    }

    .status-dropdown.check-in {
        background-color: #eff6ff;
        color: #2563eb;
        border-color: #3b82f6;
    }

    .status-dropdown.cancelled {
        background-color: #fef2f2;
        color: #dc2626;
        border-color: #ef4444;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farre\FSC_Project\resources\views/staff/staff_dashboard.blade.php ENDPATH**/ ?>