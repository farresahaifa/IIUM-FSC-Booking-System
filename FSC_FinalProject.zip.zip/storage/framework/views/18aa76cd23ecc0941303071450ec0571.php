<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IIUM Female Sports Complex</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://cdn.tailwindcss.com"></script> </head>
<body>


    <header class="top-header">
        <div class="header-branding">
            <div class="menu-toggle" onclick="toggleSidebar()">&#9776;</div>
            <img src="<?php echo e(asset('images/fsc-logo.png')); ?>" class="mini-logo">
            <div class="header-text">
                <span class="header-main">IIUM FEMALE</span>
                <span class="header-sub">SPORT COMPLEX</span>
            </div>
        </div>


        <div class="user-profile" style="display: flex; align-items: center;">
            <a href="<?php echo e(route('student.profile')); ?>" style="text-decoration: none; color: inherit; display: flex; align-items: center;">
                <?php if(auth()->guard()->check()): ?>
                    <span><?php echo e(strtoupper(Auth::user()->name)); ?></span>
                    <?php if(Auth::user()->profile_photo): ?>
                        <img src="<?php echo e(asset('storage/' . Auth::user()->profile_photo)); ?>" class="user-avatar" style="width:30px; margin-left:10px;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/profile-pic.png')); ?>" class="user-avatar" style="width:30px; margin-left:10px;">
                    <?php endif; ?>
                <?php endif; ?>
            </a>


            <?php if(auth()->guard()->check()): ?>
            <a href="#" class="header-logout"
               onclick="if(confirm('Are you sure you want to logout?')) { event.preventDefault(); document.getElementById('logout-form').submit(); }">
                LOGOUT
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
            <?php endif; ?>
        </div>
    </header>


    <?php echo $__env->yieldContent('content'); ?>


    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            if(sidebar) {
                sidebar.classList.toggle('collapsed');
            }
        }
    </script>
</body>
</html><?php /**PATH C:\Users\unzir\Desktop\FSC_FinalProject\FSC_FinalProject\resources\views/layouts/app.blade.php ENDPATH**/ ?>