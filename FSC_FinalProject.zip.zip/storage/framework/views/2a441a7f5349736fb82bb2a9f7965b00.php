<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IIUM Female Sport Complex - <?php echo e(ucfirst($sport)); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body class="bg-gray-200">






<div class="dashboard-wrapper">
    <aside class="sidebar">
        <div class="nav-links">
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">Homepage</a>
           
            <div class="booking-menu">
                <span class="menu-label">BOOK A COURT</span>
                <ul class="sport-list">
                    <li>
                        <a href="<?php echo e(route('booking.select', 'badminton')); ?>"
                           class="<?php echo e(request()->is('*badminton*') ? 'active-sport' : ''); ?>">Badminton</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('booking.select', 'netball')); ?>"
                           class="<?php echo e(request()->is('*netball*') ? 'active-sport' : ''); ?>">Netball</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('booking.select', 'pingpong')); ?>"
                           class="<?php echo e(request()->is('*pingpong*') ? 'active-sport' : ''); ?>">Ping Pong</a>
                    </li>
                </ul>
            </div>


            <div class="divider"></div>
            <a href="<?php echo e(route('student.profile')); ?>" class="<?php echo e(request()->routeIs('student.profile') ? 'active' : ''); ?>">My Profile</a>
            <a href="<?php echo e(route('student.history')); ?>" class="<?php echo e(request()->routeIs('student.history') ? 'active' : ''); ?>">Booking History</a>
        </div>
    </aside>


    <main class="main-content bg-white shadow-inner" style="overflow-y: auto;">
        <div class="px-10 py-4 text-sm font-bold flex justify-between items-center">
            <nav>
                <span class="text-gray-500">Home ></span>
                <span class="text-gray-500">Book now ></span>
                <span class="text-black"><?php echo e(ucfirst($sport)); ?></span>
            </nav>
            <a href="/booking/<?php echo e($sport); ?>" class="text-green-700 hover:underline">← Change Date</a>
        </div>


        <div class="mx-10 iium-green text-white text-center py-3 text-2xl font-medium rounded-sm shadow-sm mb-1">
            <?php echo e(ucfirst($sport === 'pingpong' ? 'Ping Pong' : $sport)); ?>

        </div>


        <div class="mx-10 date-bar text-center py-2 text-lg mb-8 shadow-sm">
            <?php echo e(\Carbon\Carbon::parse($date)->format('l j F Y')); ?>

        </div>


        <div class="px-10 pb-20">
            <?php for($i = 1; $i <= 6; $i++): ?>
                <div class="mb-10">
                    <h2 class="text-3xl font-bold mb-4">Court <?php echo e($i); ?></h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <?php
                            $timeSlots = ['2:00pm - 3:00pm', '3:00pm - 4:00pm', '4:00pm - 5:00pm', '5:00pm - 6:00pm', '8:30pm - 9:30pm', '9:30pm - 10:30pm'];
                        ?>


                        <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isBooked = $bookedSlots->where('court_number', $i)->where('time_slot', $slot)->first();
                            ?>


                            <form action="/book" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="sport_type" value="<?php echo e($sport); ?>">
                                <input type="hidden" name="court_number" value="<?php echo e($i); ?>">
                                <input type="hidden" name="booking_date" value="<?php echo e($date); ?>">
                                <input type="hidden" name="time_slot" value="<?php echo e($slot); ?>">
                               
                                <button type="submit" <?php echo e($isBooked ? 'disabled' : ''); ?>

                                    class="w-full p-5 rounded-lg text-center <?php echo e($isBooked ? 'slot-booked' : 'slot-available'); ?>">
                                    <div class="text-xl font-semibold"><?php echo e($slot); ?></div>
                                    <div class="italic text-gray-600"><?php echo e($isBooked ? 'Booked' : 'Available'); ?></div>
                                </button>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </main>
</div>


<script>
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if(sidebar) {
            sidebar.classList.toggle('collapsed');
        }
    }
</script>
</body>
</html><?php /**PATH C:\Users\unzir\Desktop\FSC_FinalProject\FSC_FinalProject\resources\views/booking/slots.blade.php ENDPATH**/ ?>