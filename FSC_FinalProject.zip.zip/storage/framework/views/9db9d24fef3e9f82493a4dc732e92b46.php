<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Details - IIUM FSC</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-100 font-sans">

    <nav class="bg-[#2D7A4D] p-4 flex justify-between items-center text-white shadow-sm">
        <div class="flex items-center gap-3">
            <img src="<?php echo e(asset('images/fsc-logo.png')); ?>" class="h-10">
            <div>
                <h1 class="font-bold leading-none uppercase text-lg">IIUM Female</h1>
                <p class="text-xs uppercase tracking-wider">Sport Complex</p>
            </div>
        </div>

        <div class="flex items-center gap-3 bg-black/10 px-4 py-2 rounded-full">
            <div class="bg-white rounded-full p-1">
                <svg class="w-5 h-5 text-black" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
            </div>
            <p class="font-bold text-sm uppercase tracking-tight"><?php echo e(Auth::user()->name); ?></p>
        </div>
    </nav>

    <div class="flex">
        <aside class="w-28 bg-[#444444] min-h-screen flex flex-col items-center py-6 gap-2">
            <a href="<?php echo e(route('dashboard')); ?>" class="w-full text-white/60 hover:text-white py-6 text-center transition uppercase tracking-widest text-lg">Home</a>
            
            <div class="bg-white w-full text-center py-6 border-l-4 border-[#2D7A4D]">
                <span class="text-black font-bold uppercase text-lg">Profil</span>
            </div>
        </aside>

        <main class="flex-1 p-8">
            <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-300">
                <div class="bg-[#37996B] p-4 text-white font-bold text-xl">
                    Booking Details
                </div>
                
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-[#37996B] text-white">
                            <th class="p-4 border-r border-[#2D7A4D]">Name</th>
                            <th class="p-4 border-r border-[#2D7A4D]">Matric No</th>
                            <th class="p-4 border-r border-[#2D7A4D]">Sports</th>
                            <th class="p-4 border-r border-[#2D7A4D]">Court</th>
                            <th class="p-4 border-r border-[#2D7A4D]">Date</th>
                            <th class="p-4 border-r border-[#2D7A4D]">Time</th>
                            <th class="p-4">Status</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-800">
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b border-gray-300 hover:bg-gray-50 transition">
                            <td class="p-4 border-r border-gray-300 font-medium"><?php echo e($booking->user_name); ?></td>
                            <td class="p-4 border-r border-gray-300 text-gray-500"><?php echo e($booking->matric_no ?? 'N/A'); ?></td>
                            
                            <td class="p-4 border-r border-gray-300 text-center">
                                <span class="inline-block px-4 py-1 bg-gray-100 border border-gray-300 rounded-lg text-sm font-semibold capitalize text-gray-700">
                                    <?php echo e($booking->sport_type); ?>

                                </span>
                            </td>

                            <td class="p-4 border-r border-gray-300 text-center">
                                <span class="inline-block px-4 py-1 bg-gray-100 border border-gray-300 rounded-lg text-sm font-semibold text-gray-700">
                                    Court <?php echo e($booking->court_number); ?>

                                </span>
                            </td>

                            <td class="p-4 border-r border-gray-300 text-center">
                                <?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('M d, Y')); ?>

                            </td>

                            <td class="p-4 border-r border-gray-300"><?php echo e($booking->time_slot); ?></td>

                            <td class="p-4 text-center">
                                <div x-data="{ open: false }" class="relative inline-block text-left">
                                    <?php
                                        // Dynamic color logic: Default is Orange (Confirmed)
                                        $statusClass = match($booking->status) {
                                            'Check-In'  => 'bg-green-100 text-green-600 border-green-300',
                                            'Cancelled' => 'bg-red-100 text-red-500 border-red-300',
                                            default     => 'bg-orange-100 text-orange-500 border-orange-300',
                                        };
                                    ?>

                                    <button @click="open = !open" type="button" class="inline-flex items-center justify-between px-3 py-1 rounded-lg border font-bold text-sm w-36 <?php echo e($statusClass); ?>">
                                        <?php echo e($booking->status ?? 'Confirmed'); ?>

                                        <svg class="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                        </svg>
                                    </button>

                                    <div x-show="open" 
                                         x-cloak
                                         @click.away="open = false" 
                                         class="absolute right-0 z-50 mt-2 w-36 bg-white border border-gray-300 rounded-md shadow-2xl overflow-hidden">
                                        <form action="<?php echo e(route('booking.updateStatus', $booking->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" name="status" value="Confirmed" class="block w-full text-left px-4 py-2 text-sm text-orange-500 hover:bg-orange-50 border-b border-gray-100">Confirmed</button>
                                            <button type="submit" name="status" value="Check-In" class="block w-full text-left px-4 py-2 text-sm text-green-600 hover:bg-green-50 border-b border-gray-100">Check-In</button>
                                            <button type="submit" name="status" value="Cancelled" class="block w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-red-50">Cancelled</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="p-10 text-center text-gray-400 font-medium italic">No active bookings available.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html><?php /**PATH C:\Users\farre\FSC_Project\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>