<!DOCTYPE html>
<html>
<head>
    <title>Booking Confirmation</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Exact colors from your mockup */
        .modal-bg { background-color: #E6F4EA; } /* Light green card */
        .check-circle { background-color: #386641; } /* Darker IIUM green */
        .btn-home { background-color: #386641; color: white; }
        .btn-home:hover { background-color: #2D5235; }
       
        /* Backdrop to mimic the screenshot's greyed-out background */
        .overlay {
            background-color: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(2px);
        }
    </style>
</head>
<body class="h-screen w-screen overflow-hidden">




    <div class="absolute inset-0 overlay flex items-center justify-center p-4">
       
        <div class="modal-bg w-full max-w-lg rounded-[40px] p-8 shadow-2xl relative flex flex-col items-center">
           
            <div class="check-circle w-24 h-24 rounded-full flex items-center justify-center mb-6">
                <svg class="w-14 h-14 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="M5 13l4 4L19 7"></path>
                </svg>
            </div>




            <h1 class="text-3xl font-bold text-gray-900 mb-6">Booking Confirmed!</h1>




            <div class="text-center space-y-1 text-xl text-gray-800 mb-6 font-medium">
                <p><?php echo e($booking->sport_type); ?></p>
                <p>Court <?php echo e($booking->court_number); ?></p>
                <p><p><?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d F Y')); ?></p></p>
            </div>




            <p class="text-red-600 text-sm italic text-center leading-tight mb-10 px-4">
                Reminder: please bring your matric card for double confirmation and come within 15 minutes from your booking time to avoid cancellation
            </p>




            <div class="mt-8 flex justify-center">
                <div class="mt-8">
                    <a href="<?php echo e(route('dashboard')); ?>"
                    class="inline-block px-8 py-3 text-white font-bold rounded-full transition-transform hover:scale-105"
                    style="background-color: #386641; text-decoration: none;">
                    Return to Homepage
                    </a>
</div>
        </div>
        </div>
    </div>




</body>
</html>
<?php /**PATH C:\Users\farre\FSC_Project(1)\resources\views/booking/confirmation.blade.php ENDPATH**/ ?>