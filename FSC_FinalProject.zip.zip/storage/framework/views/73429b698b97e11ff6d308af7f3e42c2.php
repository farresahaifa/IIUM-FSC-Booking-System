

<?php $__env->startSection('content'); ?>
<div class="login-container">
    
    <div class="branding-section">
        <div class="title-group">
            <img src="<?php echo e(asset('images/fsc-logo.png')); ?>" class="center-icon" alt="Logo">
            <div class="text-stack">
                <h1 class="main-title">IIUM FEMALE</h1>
                <h2 class="sub-title">SPORT COMPLEX INDOOR</h2>
            </div>
        </div>
    </div>

    <div class="form-section">
        <div class="login-card">
            <img src="<?php echo e(asset('images/uia-logo.png')); ?>" class="card-logo">
            
            <div class="role-toggle">
                <button type="button" class="toggle-btn active" onclick="setRole('student')">Student</button>
                <button type="button" class="toggle-btn" onclick="setRole('staff')">Staff</button>
            </div>

            <?php if($errors->any()): ?>
                <div style="color: red; margin-bottom: 10px;"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(url('/login')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                
                <input type="hidden" name="role" id="role-input" value="student">

                <div class="input-group">
                    <label id="id-label">Student ID:</label>
                    <input type="text" name="matric_number" id="id-input" placeholder="3012344" required>
                </div>
                
                <div class="input-group">
                    <label>Password:</label>
                    <input type="password" name="password" placeholder="••••••••••" required>
                </div>
                
                <button type="submit" class="btn-login">Login</button>
            </form>
        </div>
    </div>
</div>

<script>
function setRole(role) {
    const label = document.getElementById('id-label');
    const input = document.getElementById('id-input');
    const roleInput = document.getElementById('role-input'); 
    const buttons = document.querySelectorAll('.toggle-btn');

    // Update the hidden value so the Controller knows the role
    roleInput.value = role;

    // Update button visual state
    buttons.forEach(btn => btn.classList.remove('active'));
    
    // Find the button that was clicked and make it blue/active
    const clickedButton = Array.from(buttons).find(btn => btn.innerText.toLowerCase() === role);
    if(clickedButton) clickedButton.classList.add('active');

    // Change labels based on selection
    if (role === 'staff') {
        label.innerText = 'Staff ID:';
        input.placeholder = 'Staff Number (e.g. STAFF123)';
    } else {
        label.innerText = 'Student ID:';
        input.placeholder = '3012344';
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farre\FSC_Project(1)\resources\views/login.blade.php ENDPATH**/ ?>