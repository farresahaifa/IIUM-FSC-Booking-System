

<?php $__env->startSection('content'); ?>
<style>
    /* 1. Prevent layout-level scrolling */
    body, html {
        overflow: hidden !important;
        height: 100%;
    }

    /* 2. Darkened Background with Overlay */
    .profile-page-bg {
        /* This creates a 50% black overlay over your image */
        background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                    url("<?php echo e(asset('images/welcome-bg.png')); ?>"); 
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        height: calc(100vh - 70px); 
        margin: -20px; 
        padding: 40px;
        overflow: hidden;
    }

    /* 3. Make the card slightly transparent (Glassmorphism effect) */
    .profile-card {
        background: rgba(255, 255, 255, 0.9) !important; /* 90% white opacity */
        backdrop-filter: blur(5px); /* Blurs the background behind the card */
        border: 1px solid rgba(255, 255, 255, 0.3);
        transform: scale(0.9);
        transform-origin: top center;
    }

    .profile-container {
        max-width: 1200px;
        margin: 0 auto;
        height: 100%;
    }

    .breadcrumb-nav, .breadcrumb-nav a {
        color: rgba(255, 255, 255, 0.8) !important;
    }
</style>

<div class="profile-page-bg">
    <div class="profile-container">
        <nav class="breadcrumb-nav">
            <a href="<?php echo e(route('staff.dashboard')); ?>">Home</a>
            <span> > </span>
            <span style="color: white;">My Profile</span>
        </nav>

        <h1 style="color: white; font-size: 2.5rem; font-weight: bold; margin-bottom: 20px;">My Profile</h1>

        <div class="profile-card">
            <h2 class="display-name"><?php echo e(strtoupper($user->name)); ?></h2>
            
            <div class="profile-img-box">
                <?php if($user->profile_photo): ?>
                    <img src="<?php echo e(asset('storage/' . $user->profile_photo)); ?>" alt="User Photo">
                <?php else: ?>
                    <img src="<?php echo e(asset('images/profile-pic.png')); ?>" alt="User Icon">
                <?php endif; ?>
            </div>

            <div class="user-status">ACTIVE (STAFF)</div>

            <div class="info-footer" style="text-align: left; padding-left: 20px;">
                <p><strong>STAFF ID: <?php echo e($user->matric_number); ?> | ACTIVE</strong></p>
                <p><?php echo e(strtoupper($user->email)); ?></p>
                <p>POSITION: <?php echo e(strtoupper($user->role)); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.staff_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\farre\FSC_Project(1)\resources\views/staff/profile.blade.php ENDPATH**/ ?>